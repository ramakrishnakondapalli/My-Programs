#include "ports.h"
#include "lcd.h"
#include "rtc.h"

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**** Periphiral addresses ****
~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

static bit_8 rtc_recv_val[7] _at_ 0x30;
bit_8 bdata a;
sbit LSB=a ^ 0;
sbit MSB=a ^ 7;

extern bit aon,aoff;

bit_8 code *rtc[]={"0","1","2","3","4","5","6","7","8","9","10","11","12"};
bit_8 code *day[]={"*SUN*","*MON*","*TUE*","*WED*","*THU*","*FRI*","*SAT*"};
bit_8 code *pmam[]={"am","pm"};
bit_8 rtc_ini_val[9],ahours,amins;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**** Displaying special data ****
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void disp_data_rtc(bit_8 x)
{
	bit_8 temp;
	temp = x/0x10;
	wrt_data(rtc[temp]);
	temp = x%0x10;
	wrt_data(rtc[temp]);
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~
**** RTC start condition ****
~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void start_rtc(void)
{
	scl=0;
	sda=1;
	DELAY;
	scl=1;
	DELAY;
	sda=0;
}

void stop_rtc(void)
{
	DELAY;
	sda=0;
	scl=1;
	DELAY;
	sda=1;
	DELAY;
	scl=0;
}

void send_adr(bit_8 x)
{
	bit_8 j;
	a=x;
	for(j=0;j<8;j++)
	{
		scl=0;
		DELAY;
		sda=MSB;
		a<<=1;
		_nop_();
		scl=1;
		DELAY;
		scl=0;
	}
	sda=1;
	scl=1;
	DELAY;
	scl=0;
	DELAY;
}

void recv_data()
{
	bit_8 y;
	for(y=0;y<0x1d;y++)
	{
		if(y<=6)
			rtc_recv_val[y]=recv_rtc();
		else
			recv_rtc();
	}
	stop_rtc();
}

bit_8 recv_rtc()
{
	bit_8 j;
	for(j=0;j<8;j++)
	{
		sda=1;
		scl=1;
		DELAY;
		LSB=sda;
		if(j<7)
			a<<=1;
		DELAY;
		scl=0;
		DELAY;
	}
	sda=1;
	scl=0;
	DELAY;
	sda=0;
	scl=1;
	DELAY;
	scl=0;
	DELAY;
	return a;
}

void RTC_INI(void)
{
	bit_8 t;
	for(t=0;t<9;t++)
	{
		start_rtc();
		send_adr(0xd0);
		send_adr(t);
		send_adr(rtc_ini_val[t]);
		stop_rtc();
	}
	wrt_cmd(0x1);
}

void disp_rtc(void)
{
	wrt_cmd(0xca);
	disp_data_rtc(rtc_recv_val[0]);
	wrt_cmd(0xc7);
	disp_data_rtc(rtc_recv_val[1]);
	wrt_byte(':');
	wrt_cmd(0xc4);
	disp_data_rtc(rtc_recv_val[2]&0x1F);
	wrt_byte(':');
	wrt_cmd(0xcd);
	if((rtc_recv_val[2]&20)==20)
		wrt_data(pmam[1]);
	else
		wrt_data(pmam[0]);
	wrt_cmd(0x81);
	wrt_data(day[rtc_recv_val[3]-1]);
	wrt_cmd(0x88);
	disp_data_rtc(rtc_recv_val[4]);
	wrt_byte('/');
	disp_data_rtc(rtc_recv_val[5]);
	wrt_byte('/');
	disp_data_rtc(rtc_recv_val[6]);
	wrt_cmd(0xC0);
	wrt_byte(BELL);
	wrt_byte(SPEAKER_OFF);
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**** Setting the time of RTC ****
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void rtc_set()
{
	bit_8 mins,hours,days,date,month,year;
	bit ampm;
	mins = hex_dec(rtc_recv_val[1]);
	hours = hex_dec(rtc_recv_val[2]&0x1F);
	if(rtc_recv_val[2]&0x20==0x20)
		ampm=0;
	else
		ampm=1;
	days = hex_dec(rtc_recv_val[3]);
	date = hex_dec(rtc_recv_val[4]);
	month = hex_dec(rtc_recv_val[5]);
	year = hex_dec(rtc_recv_val[6]);
	wrt_cmd(1);
	wrt_cmd(0x80);
	wrt_byte(CLOCK);
	wrt_data(" Set");
	wrt_cmd(0x8C);
	wrt_data("Time");
	wrt_cmd(0x0e);
	wrt_cmd(0xc4);
	data_in(hours);
	wrt_byte(':');
	data_in(mins);
	if(ampm)
		wrt_data(pmam[1]);
	else
		wrt_data(pmam[0]);
	wrt_cmd(0xC8);
	while(time_key==0);
up:	while(increment!=0&&decrement!=0&&time_key!=0);
	if(increment==0)
	{
		mins++;
		if(mins==60)
			mins=0;
		wrt_cmd(0xC7);
		data_in(mins);
		wrt_cmd(0x10);
		delay();
		goto up;
	}
	if(decrement==0)
	{
		mins--;
		if(mins==0xff)
			mins=59;
		wrt_cmd(0xC7);
		data_in(mins);
		wrt_cmd(0x10);
		delay();
		goto up;
	}
	while(time_key==0);
	wrt_cmd(0xC5);

up1:while(increment!=0&&decrement!=0&&time_key!=0);
	if(increment==0)
	{
		hours++;
		if(hours==13)
			hours=1;
		if(hours==12)
			ampm=~ampm;
		wrt_cmd(0xC4);
		data_in(hours);
		wrt_cmd(0xCA);
		if(ampm)
			wrt_data("pm");
		else
			wrt_data("am");
		wrt_cmd(0xC5);
		delay();
		goto up1;
	}
	if(decrement==0)
	{
		hours--;
		if(hours==0)
		{
			hours=12;
			ampm=~ampm;
		}
		wrt_cmd(0xC4);
		data_in(hours);
		wrt_cmd(0xCA);
		if(ampm)
			wrt_data("pm");
		else
			wrt_data("am");
		wrt_cmd(0xC5);
		delay();
		goto up1;
	}
	while(time_key==0);
	wrt_cmd(1);
	wrt_cmd(0x80);
	wrt_byte(CLOCK);
	wrt_data(" Set");
	wrt_cmd(0x8c);
	wrt_data("Date");
	wrt_cmd(0xc4);
	data_in(date);
	wrt_byte('/');
	data_in(month);
	wrt_byte('/');
	data_in(year);
	wrt_cmd(0xc5);
up2:while(increment!=0&&decrement!=0&&time_key!=0);
	if(increment==0)
	{
		date++;
		if(date==32)
			date=1;
		wrt_cmd(0xC4);
		data_in(date);
		wrt_cmd(0x10);
		delay();
		goto up2;
	}
	if(decrement==0)
	{
		date--;
		if(date==0)
			date=31;
		wrt_cmd(0xC4);
		data_in(date);
		wrt_cmd(0x10);
		delay();
		goto up2;
	}
	while(time_key==0);
	wrt_cmd(0xC8);
up3:while(increment!=0&&decrement!=0&&time_key!=0);
	if(increment==0)
	{
		month++;
		if(month==13)
			month=1;
		wrt_cmd(0xC7);
		data_in(month);
		wrt_cmd(0x10);
		delay();
		goto up3;
	}
	if(decrement==0)
	{
		month--;
		if(month==0)
			month=12;
		wrt_cmd(0xC7);
		data_in(month);
		wrt_cmd(0x10);
		delay();
		goto up3;
	}
	while(time_key==0);
	wrt_cmd(0xCB);
up4:while(increment!=0&&decrement!=0&&time_key!=0);
	if(increment==0)
	{
		year++;
		if(year==100)
			year=0;
		wrt_cmd(0xCA);
		data_in(year);
		wrt_cmd(0x10);
		delay();
		goto up4;
	}
	if(decrement==0)
	{
		year--;
		if(year==0xff)
			year=99;
		wrt_cmd(0xCA);
		data_in(year);
		wrt_cmd(0x10);
		delay();
		goto up4;
	}
	while(time_key==0);
	wrt_cmd(1);
	wrt_cmd(0x80);
	wrt_byte(CLOCK);
	wrt_data(" Set");
	wrt_cmd(0x8c);
	wrt_data("Day");
	wrt_cmd(0xc4);
	wrt_data(day[days-1]);
up6:while(increment!=0&&decrement!=0&&time_key!=0);
	if(increment==0)
	{
		days++;
		if(days==8)
			days=1;
		wrt_cmd(0xC4);
		wrt_data(day[days-1]);
		delay();
		goto up6;
	}
	if(decrement==0)
	{
		days--;
		if(days==0)
			days=7;
		wrt_cmd(0xC4);
		wrt_data(day[days-1]);
		delay();
		goto up6;
	}
	while(time_key==0);
	wrt_cmd(1);
	wrt_cmd(0xC);
	rtc_ini_val[0] = 0x00;
	rtc_ini_val[1] = dec_hex(mins);
	rtc_ini_val[2] = dec_hex(hours);
	if(ampm)
		rtc_ini_val[2]+=0x60;
	else
		rtc_ini_val[2]+=0x40;
	rtc_ini_val[3] = dec_hex(days);
	rtc_ini_val[4] = dec_hex(date);
	rtc_ini_val[5] = dec_hex(month);
	rtc_ini_val[6] = dec_hex(year);
	rtc_ini_val[7] = 0x00;
	rtc_ini_val[8] = '~';
	RTC_INI();
	wrt_cmd(1);
	wrt_cmd(0x82);
	wrt_byte(OK);
	wrt_data(" Time set");
	wrt_cmd(0xC3);
	wrt_byte(MUSIC);
	wrt_data(" Enjoy! ");
	wrt_byte(MUSIC);
	delay();
	delay();
	delay();
	delay();
	delay();
	wrt_cmd(1);

}

void rtc_check(void)
{
	bit_8 temp;
	start_rtc();
	send_adr(0xd0);
	send_adr(0x08);
	start_rtc();
	send_adr(0xd1);
	temp=recv_rtc();
	stop_rtc();
	if(temp!='~')
	{
		rtc_ini_val[0]=0x00;
		rtc_ini_val[1]=0x00;
		rtc_ini_val[2]=0x52;
		rtc_ini_val[3]=0x1;
		rtc_ini_val[4]=0x1;
		rtc_ini_val[5]=0x1;
		rtc_ini_val[6]=0x6;
		rtc_ini_val[7]=0x0;
		rtc_ini_val[8]='~';
		RTC_INI();
	}
}								

bit_8 hex_dec(bit_8 hex)
{
	return((hex/0x10)*0xA+(hex%0x10));
}

bit_8 dec_hex(bit_8 dec)
{
	return((dec/0xA)*0x10+(dec%0xA));
}

void delay(void)//this delay is can be changed according to the
{				//speed requirement for the parameter values while changing.
	bit_8 i,j;
	TMOD=0x11;
	for(i=0;i<2;i++)
	{
		TH1=0;
		TH0=1;
		TL1=0;
		TL0=0;
		TR1=1;
		while(TF1!=1)
		{
			for(j=0;j<20;j++);
		}
		TF1=0;
		TR0=1;
		TR1=0;
		while(TF0!=1)
		{}
		TF0=0;
		TR0=0;
	}
}

void data_in(bit_8 a)
{
	bit_8 j;
	j=a/10;
	wrt_data(rtc[j]);
	j=a%10;
	wrt_data(rtc[j]);
}

void set_alarm()
{
	bit ampm;
	ahours=hex_dec(rtc_recv_val[2]&0x1f);
	amins=hex_dec(rtc_recv_val[1]);
	wrt_cmd(1);
	wrt_cmd(0x80);
	wrt_byte(CLOCK);
	wrt_data(" Set");
	wrt_cmd(0x8B);
	wrt_data("Alarm");
	wrt_cmd(0x0e);
	wrt_cmd(0xc4);
	data_in(ahours);
	wrt_byte(':');
	data_in(amins);
	if(ampm)
		wrt_data(pmam[1]);
	else
		wrt_data(pmam[0]);
	wrt_cmd(0xC8);
	while(alarm_key==0);
aup:
	while(increment!=0&&decrement!=0&&alarm_key!=0);
	if(increment==0)
	{
		amins++;
		if(amins==60)
			amins=0;
		wrt_cmd(0xC7);
		data_in(amins);
		wrt_cmd(0x10);
		delay();
		goto aup;
	}
	if(decrement==0)
	{
		amins--;
		if(amins==0xff)
			amins=59;
		wrt_cmd(0xC7);
		data_in(amins);
		wrt_cmd(0x10);
		delay();
		goto aup;
	}
	while(alarm_key==0);
	wrt_cmd(0xC5);

aup1:
	while(increment!=0&&decrement!=0&&alarm_key!=0);
	if(increment==0)
	{
		ahours++;
		if(ahours==13)
			ahours=1;
		if(ahours==12)
			ampm=~ampm;
		wrt_cmd(0xC4);
		data_in(ahours);
		wrt_cmd(0xCA);
		if(ampm)
			wrt_data("pm");
		else
			wrt_data("am");
		wrt_cmd(0xC5);
		delay();
		goto aup1;
	}
	if(decrement==0)
	{
		ahours--;
		if(ahours==0)
		{
			ahours=12;
			ampm=~ampm;
		}
		wrt_cmd(0xC4);
		data_in(ahours);
		wrt_cmd(0xCA);
		if(ampm)
			wrt_data("pm");
		else
			wrt_data("am");
		wrt_cmd(0xC5);
		delay();
		goto aup1;
	}
	amins = dec_hex(amins);
	ahours = dec_hex(ahours);
	if(ampm)
		ahours+=0x60;
	else
		ahours+=0x40;
	wrt_cmd(1);
	wrt_cmd(0x82);
	wrt_byte(OK);
	wrt_data(" Alarm set");
	wrt_cmd(0xC3);
	wrt_byte(MUSIC);
	wrt_data(" Enjoy! ");
	wrt_byte(MUSIC);
	delay();
	delay();
	delay();
	delay();
	delay();
	wrt_cmd(1);
	wrt_cmd(0xc);
	wrt_cmd(0xc2);
	wrt_byte(SPEAKER_ON);
}

void check_alarm()
{
	if(ahours==rtc_recv_val[2])
		if(amins==rtc_recv_val[1])
		{
			aoff=1;
			aon=0;
		}
}

void ring_alarm()
{
	alarm_port=0;
	delay();
	alarm_port=~alarm_port;
	delay();
	alarm_port=~alarm_port;
	delay();
	alarm_port=~alarm_port;
	delay();
	alarm_port=~alarm_port;
	delay();
	alarm_port=~alarm_port;
	delay();
	alarm_port=~alarm_port;
	delay();
	alarm_port=~alarm_port;
}