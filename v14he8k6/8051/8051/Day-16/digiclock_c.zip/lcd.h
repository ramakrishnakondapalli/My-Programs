#ifndef __LCD_H__
#define __LCD_H__

#include "ports.h"

void wrt_cmd(bit_8);
void wrt_data(bit_8*);
void LCD_INI(void);
void busy(void);
void wrt_byte(bit_8);
void build_ram();
void disp_const(void);
void disp_intro(void);

#endif
