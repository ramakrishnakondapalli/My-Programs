#ifndef __PORTS_H
#define __PORTS_H

#include <AT89X51.H>
#include <INTRINS.H>

#define sda P1_1
#define scl P1_0
#define rs P3_7
#define rw P3_6
#define en P3_5
#define alarm_key P3_3
#define time_key P3_2
#define increment P1_3
#define decrement P1_2
#define alarm_port P1_4
#define lcd_port P2
#define D7 P2_7
#define BELL 0
#define SPEAKER_OFF 1
#define SPEAKER_ON 2
#define CLOCK 3
#define OK 4
#define HEART 5
#define MUSIC 6

typedef unsigned char bit_8;
typedef unsigned int bit_16;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**** Some Required Macros ****
~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#define DELAY _nop_(); _nop_(); _nop_()
#define DISABLE_INT IE=0x0;
#define ENABLE_INT IE=0x85;

#endif