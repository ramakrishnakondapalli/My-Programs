the circuit diagram is same as the old DS1307 project.
this software is still under construction.
its just a beta version of the software.
give it a try.
if you find any bug. post it on the website's forum

www.rickeyworld.tk