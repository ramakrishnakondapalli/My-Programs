#include "ports.h"
#include "lcd.h"
#include "rtc.h"

bit flag=0,aflag=0,aon=0,aoff=0;

void main()
{
	LCD_INI();
	build_ram();
	rtc_check();
	disp_intro();
	ENABLE_INT
	wrt_cmd(0x1);
	wrt_cmd(0x1);
	start_rtc();
	send_adr(0xd0);
	send_adr(0x00);
	start_rtc();
	send_adr(0xd1);
	recv_data();
	while(1)
	{
		start_rtc();
		send_adr(0xd0);
		send_adr(0x00);
		start_rtc();
		send_adr(0xd1);
		recv_data();
		disp_rtc();
		if(_testbit_(flag))
		{
			DISABLE_INT
			rtc_set();
			ENABLE_INT
			flag=0;
		}
		if(_testbit_(aflag))
		{
			DISABLE_INT
			set_alarm();
			ENABLE_INT
			aflag=0;
		}
		if(aon)
			check_alarm();
		if(aoff)
			ring_alarm();
	}
}

void set_flag() interrupt 0
{
	flag=1;
}

void set_aflag() interrupt 2
{
	aflag=1;
	if(aoff)
	{
		aoff=0;
		aflag=0;
		aon=0;
	}
}
