#ifndef __RTC_H__
#define __RTC_H__

#include "ports.h"

void RTC_INI(void);
void start_rtc(void);
void send_adr(bit_8);
void recv_data(void);
void stop_rtc(void);
void disp_day_rtc(bit_8);
void disp_rtc(void);
void rtc_set(void);
bit_8 recv_rtc(void);
void rtc_check(void);
bit_8 hex_dec(bit_8);
bit_8 dec_hex(bit_8);
void data_in(bit_8);
void delay(void);
void set_alarm(void);
void check_alarm(void);
void ring_alarm();

#endif
