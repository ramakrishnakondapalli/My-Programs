//------------------------------------------------------------------------------
// Keil Software, Inc.
// 
// Project: 	I2C EXAMPLE PROGRAM (BIT BANGED) FOR ADuC812 MCU
//
// Filename: 	ADuC812_I2C_Example.c
// Version: 	1.0.0
// Description:	This file contains example code to print over the serial
//				port of the ADuC812 MCU and Evaultion Board (EVAL-ADuC812QS).
//				This example will test the I2C function of the ADuC812.
//				This will be done by writing and reading from
//				a serial EEPROM (24LC65).
//				
//				The example work with communicate at: 9600, 8, N, 1.
//
//				CPU Frequency: 11.0592 MHz
//
// Copyright 2000 - Keil Software, Inc.
// All rights reserved.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Header files
//------------------------------------------------------------------------------
#include "ADuC812.H"						// Header file for the ADuC812 MCU
#include <STDIO.H>							// Standard I/O header file

sbit  P3_4 	= 0xB4;							// Define the individual bit

//------------------------------------------------------------------------------
// Value Definitions
//------------------------------------------------------------------------------
#define 	TRUE			0x01			// Value representing TRUE
#define		FALSE			0x00			// Value representing FALSE
#define 	ON				0x01			// Value representing ON
#define		OFF				0x00			// Value representing OFF
#define 	HIGH			0x01			// Value representing HIGH
#define		LOW				0x00			// Value representing LOW
#define 	YES				0x01			// Value representing YES
#define		NO				0x00			// Value representing NO

#define  	DELAY_WRITE		20				// Value for delay write time
#define  	DELAY_BLINK		500				// Value for delay time - blink

//------------------------------------------------------------------------------
// Macros
//------------------------------------------------------------------------------
											// Get high byte macro
#define high_byte(x)		((x & 0xFF00) >> 8)

//------------------------------------------------------------------------------
// I/O Port Defines
//------------------------------------------------------------------------------
#define  	LED				P3_4			// LED Output

//------------------------------------------------------------------------------
// I2C Peripheral Function Prototypes
//------------------------------------------------------------------------------
											// Writes a byte to the EEPROM
void write_byte (unsigned char data_out, unsigned int address);
											// Reads a bytee from the EEPROM
unsigned char read_byte (unsigned int address);

//------------------------------------------------------------------------------
// I2C Functions - Master
//------------------------------------------------------------------------------
void i2c_init (void);						//  Initialize I2C
void i2c_start (void);						//	Sends I2C Start Trasfer
void i2c_stop (void);						//	Sends I2C Stop Trasfer
bit i2c_write (unsigned char input_data);	//	Writes data over the I2C bus
unsigned char i2c_read (bit send_ack);		//	Reads data from the I2C bus

//------------------------------------------------------------------------------
// Support Function Prototypes
//------------------------------------------------------------------------------
void initialize_system (void);				// Initializes MCU, except I2C
void delay_time (unsigned int time_end);    // To pause execution for pre-determined time

//------------------------------------------------------------------------------
// Global Variables
//------------------------------------------------------------------------------
unsigned int timeout_counter;				// Variable used for delay routines 

//------------------------------------------------------------------------------
// MAIN FUNCTION 
//------------------------------------------------------------------------------
void main (void)
{
	unsigned int eeprom_address;

	initialize_system();
	i2c_init();

	printf("\n\rKeil Software, Inc.\n\r");	// Display starup message
	printf("ADuC812 MCU I�C Example Test Program\n\r");
	printf("Version 1.0.0\n\r");
	printf("Copyright 2000 - Keil Software, Inc.\n\r");
	printf("All rights reserved.\n\n\r");

	printf("Writing data to EEPROM....");
	for (eeprom_address = 0; eeprom_address < 75; eeprom_address++)
		write_byte((unsigned char)eeprom_address + 0x30, eeprom_address);

	printf("Done!\n\r");
	printf("Reading from EEPROM...ASCII table!\n\r");

	while (TRUE)
	{										
		for (eeprom_address = 0; eeprom_address < 75; eeprom_address++)
		{
			delay_time(DELAY_BLINK);		// Blink LED with delay
			LED = ON;
			delay_time(DELAY_BLINK);
			LED = OFF;

			printf("Address: %3u	Character: %c\n\r", eeprom_address, read_byte(eeprom_address));
		}
	}
}

//------------------------------------------------------------------------------
// I2C Peripheral Function Prototypes
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Procedure:	write_byte
// Inputs:		data out, address
// Outputs:		none
// Description:	Writes a byte to the EEPROM given the address 
//------------------------------------------------------------------------------
void write_byte (unsigned char data_out, unsigned int address)
{
	i2c_start();							// Send start signal
	i2c_write(0xA0); 		       			// Send identifier I2C address
	i2c_write(high_byte(address)); 			// Send address to EEPROM
   	i2c_write((unsigned char)address);  	// Send address to EEPROM
   	i2c_write(data_out);            		// Send low byte to EEPROM
   	delay_time(DELAY_WRITE);       			// Delay a period of time to write
   	i2c_stop();                   			// Send I2C Stop Transfer
   	delay_time(DELAY_WRITE);       			// Delay a period of time to write
}

//------------------------------------------------------------------------------
// Procedure:	read_byte
// Inputs:		address
// Outputs:		none
// Description:	Reads a byte from the EEPROM given the address 
//------------------------------------------------------------------------------
unsigned char read_byte (unsigned int address)
{
	unsigned char data_in;

	i2c_start();							// Send start signal

	i2c_write(0xA0);              			// Send identifer I2C address
   	i2c_write(high_byte(address));   		// Send address to EEPROM
   	i2c_write((unsigned char)address);  	// Send address to EEPROM
	i2c_start();            				// Send I2C Start Transer
	i2c_write(0xA1);              			// Send identifer I2C address
   	data_in = i2c_read(NO);	       			// Read byte
   	i2c_stop();                   			// Send I2C Stop Transfer

   	return data_in;                 
}

//------------------------------------------------------------------------------
// I2C Functions - Master
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// 	Routine:	i2c_init
//	Inputs:		none
//	Outputs:	none
//	Purpose:	Initialize I2C for the ADu812C
//------------------------------------------------------------------------------
void i2c_init (void)
{
											// To initialize we need the output
											// data high, the clock high, and
											// the I2C system in Master mode

	I2CM = HIGH;							// Set master mode
	MDO = HIGH;								// Set the data bit to HIGH
	MDE = FALSE;							// We are not using the pin yet
	MCO = HIGH;								// Set the clock bit to HIGH
}

//------------------------------------------------------------------------------
// 	Routine:	i2c_start
//	Inputs:		none
//	Outputs:	none
//	Purpose:	Sends I2C Start Trasfer - State "B"
//------------------------------------------------------------------------------
void i2c_start (void)
{
											// An I2C start sequence is defined as
											// a High to Low Transistino on the data
											// line as the CLK pin is high

	MDE = TRUE;								// Master Mode Data Output Enable: ON
	MDO = HIGH;
	MCO = HIGH;
	
	MDO = LOW;								// Master Mode Data Output: LOW
	MDO = LOW;								// Repeat for delay
	MCO = LOW;								// Master Mode Clock Output: LOW
}

//------------------------------------------------------------------------------
// 	Routine:	i2c_stop
//	Inputs:		none
//	Outputs:	none
//	Purpose:	Sends I2C Stop Trasfer - State "C"
//------------------------------------------------------------------------------
void i2c_stop (void)
{
											// An I2C start sequence is defined as
											// a Low to High Transistino on the data
											// line as the CLK pin is high

	MDE = TRUE;								// Master Mode Data Output Enable: ON
	MDO = LOW;								// Master Mode Data Output: LOW
	MCO = HIGH;								// Master Mode Clock Output: HIGH
	MCO = HIGH;								// Repeat for delay
	MDO = HIGH;								// Master Mode Data Output: LOW
}

//------------------------------------------------------------------------------
// 	Routine:	i2c_write
//	Inputs:		output byte
//	Outputs:	none
//	Purpose:	Writes data over the I2C bus
//------------------------------------------------------------------------------
bit i2c_write (unsigned char output_data)
{
	unsigned char index;
											// An I2C output byte is bits 7-0
										 	// (MSB to LSB).  Shift one bit at a time
											// to the MDO output, and then clock the
											// data to the I2C Slave

	MDE = TRUE;								// Master Mode Data Output Enable: ON
	for(index = 0; index < 8; index++)  	// Send 8 bits out the port
	{
                                 			// Output the data bit to the EEPROM
		MDO = ((output_data & 0x80) ? 1 : 0);
      	output_data  <<= 1;            		// Shift the byte by one bit
		MCO = HIGH;   		        		// Clock the data into the EEPROM
		MCO = HIGH;   		        		// Repeat for delay
		MCO = LOW;					
	}

	MDE = FALSE;							// Put data pin into read mode
	MCO = HIGH;								// Get ACK bit
	if (!MDI)
    {
		MCO = LOW;							// Clock Low
		return TRUE;						// ACK from slave
	}
	else
	{
		MCO = LOW;							// Clock Low
		return FALSE;						// No ACK
	}
}

//------------------------------------------------------------------------------
// 	Routine:	i2c_read
//	Inputs:		send_ack (if TRUE send the ACK signal)
//	Outputs:	input byte
//	Purpose:	Reads data from the I2C bus
//------------------------------------------------------------------------------
unsigned char i2c_read (bit send_ack)
{
	unsigned char index, input_data;

	input_data = 0x00;
	
	MDE = FALSE;							// Put data pin into read mode
	MCO = LOW;								// Set clock LOW

	for(index = 0; index < 8; index++)  	// Get 8 bits from the device
	{
     	input_data <<= 1;					// Shift the data right 1 bit
		MCO = HIGH;							// Clock the data into the register
		MCO = HIGH;							// Repeat for delay
		MCO = LOW;							
		input_data |= MDI;					// Read the data bit
	}
	
	MDE = TRUE;								// Put data pin into write mode
	if (send_ack) MDO = LOW;				// Set data pin LOW to Ack the read
	else MDO = HIGH;						// Set data pin HIGH to Not Ack the read

	MCO = HIGH;								// Set the clock pin HIGH
	MCO = HIGH;								// Repeat for delay
	MCO = LOW;								// Set the clock pin LOW
	MDO = LOW;								// Set the data pin LOW
	MDO = LOW;								// Repeat for delay
	MDE = LOW;								// Put data pin into read mode

   	return input_data;
}


//------------------------------------------------------------------------------
// SUPPORT FUNCTIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Procedure:	initialize_system
// Inputs:		none
// Outputs:		none
// Description:	Initializes embedded system MCU LPC764
//------------------------------------------------------------------------------
void initialize_system (void)
{
// Initialize the serial port (9600, 8, N, 1) [see page 32 of data sheet]
	PCON &= 0x7F;							// Clear bit 7 of the PCON register (SMOD1 = 0)  
	SCON = 0x50;							// 0101,0000 (Mode 1 and RxD enable)			
	TMOD |= 0x22;							// Timer #0 and #1 in autoreload 8 bit mode
	TCON = 0x40;							// Set Timer #1 to run mode
	TH1 = 0xFD;								// Baud rate is determined by
											// Timer #1 overflow rate
											// Baud Rate = (Fcpu / 384) / (256 - TH1)
											// Fcpu = 11.0592 MHz
											// TH1 = 253
	TR1 = 1;								// Turn on Timer 1
	TR0 = 1;								// Turn on Timer 0
	TI = 1;									// Set UART to send first char

	IE = 0x82;								// Turn on Timer #0 interrupts (bit 1 and 7)
}

////////////////////////////////////////////////////////////////////////////////
// 	Routine:	delay_time
//	Inputs:		counter value to stop delaying
//	Outputs:	none
//	Purpose:	To pause execution for pre-determined time
////////////////////////////////////////////////////////////////////////////////
void delay_time (unsigned int time_end)
{
	timeout_counter = 0x0000;
	while (timeout_counter < time_end);
}

////////////////////////////////////////////////////////////////////////////////
// 	Routine:	timer_0_isr
//	Inputs:		none
//	Outputs:	none
//	Purpose:	Interrupt Service Routine for Timer #0
////////////////////////////////////////////////////////////////////////////////
void timer_0_isr (void) interrupt 1
{
	timeout_counter++;					// Increment time-delay counter
	if (timeout_counter > 64000) timeout_counter = 64000;
}

